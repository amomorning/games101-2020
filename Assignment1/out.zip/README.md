## Rotate at any aixes

### Usage:
``` bash
mkdir build
cd build
cmake ..
make

/.Rasterizer -a
```
### Input

The first and only line of input consists of 3 real numbers, $ x, y, z $, present for the rotation axies P.
``` cpp
1 2 3
```

After input the axies, you can use `D` and `A` to rotate the triangle.
